export default async (request, context) => {
  const userAgent = request.headers.get("user-agent") || "";

  const isBrowser = 
    userAgent.includes("Mozilla") || 
    userAgent.includes("Chrome") || 
    userAgent.includes("Safari") || 
    userAgent.includes("Edge") || 
    userAgent.includes("Opera") || 
    userAgent.includes("OPR") || 
    userAgent.includes("Firefox") || 
    userAgent.includes("Windows") || 
    userAgent.includes("Macintosh");

  if (isBrowser) {
    return new Response("Acceso denegado. Este recurso solo puede ser utilizado mediante inyector.", {
      status: 403,
      headers: { "content-type": "text/plain; charset=utf-8" },
    });
  }

  return context.next();
};
